package areas_triangulos

import kotlin.math.pow
import kotlin.math.sqrt
fun calcAreaTriEquilatero(lado: Double): Double {
    return (lado.pow(2) * sqrt(3.0)) / 4
}
fun main(args: Array<String>){
    //função para calcular a área do triângulo equilátero
    val ladoTriEquilatero = 6.0
    val areaTriEquilatero = calcAreaTriEquilatero(ladoTriEquilatero)
    println("A área do triângulo equilátero é: $areaTriEquilatero")
}