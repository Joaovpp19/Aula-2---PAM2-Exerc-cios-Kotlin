package areas_triangulos

fun calcAreaTriIsosceles(base: Double, alt: Double): Double {
    return (base * alt) / 2
}
fun main(args: Array<String>) {
    //função para calcular a área do triângulo isósceles
    val baseTriIsosceles = 4.0
    val altTriIsosceles = 6.0
    val areaTrianguloIsosceles = calcAreaTriIsosceles(baseTriIsosceles, altTriIsosceles)
    println("A área do triângulo isósceles é: $areaTrianguloIsosceles")
}
