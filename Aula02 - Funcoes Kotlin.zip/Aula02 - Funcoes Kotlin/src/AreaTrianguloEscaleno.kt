package areas_triangulos

fun calcAreaTriEscaleno(base: Double, altura: Double): Double {
    return (base * altura) / 2
}
fun main(args: Array<String>) {
    // Exemplo de uso da função para calcular a área do triângulo escaleno
    val baseTriEscaleno = 5.0
    val altTriEscaleno = 3.0
    val areaTrianguloEscaleno = calcAreaTriEscaleno(baseTriEscaleno, altTriEscaleno)
    println("A área do triângulo escaleno é: $areaTrianguloEscaleno")
}
