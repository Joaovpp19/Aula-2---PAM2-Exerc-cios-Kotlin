package areas

import kotlin.Double
fun calcAreaTrapezio(baseMaior: Double, baseMenor: Double, alt: Double): Double {
    return ((baseMaior + baseMenor) * alt) / 2

}
fun main(args: Array<String>){
    //função para calcular a área do trapézio
    val baseMaiorTrap = 7.0
    val baseMenorTrap = 5.0
    val altTrap = 3.0
    val areaTrapezio = calcAreaTrapezio(baseMaiorTrap, baseMenorTrap, altTrap)
    println("A área do trapézio é: $areaTrapezio")
}