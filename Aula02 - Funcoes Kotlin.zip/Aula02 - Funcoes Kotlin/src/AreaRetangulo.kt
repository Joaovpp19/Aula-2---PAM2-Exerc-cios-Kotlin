package areas

fun calcularAreaRetangulo (base: Double, altura: Double): Double {
    return base * altura
}
fun main(args: Array<String>){
    //função para calcular a área do retângulo
    val baseRetangulo = 5.0
    val alturaRetangulo = 8.0
    val areaRetangulo = calcularAreaRetangulo(baseRetangulo, alturaRetangulo)

    println("A área do retângulo é: $areaRetangulo")
}