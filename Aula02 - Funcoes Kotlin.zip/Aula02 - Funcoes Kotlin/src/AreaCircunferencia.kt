package areas
//importando um pacote kotlin para calcular o PI da circunferência
import kotlin.math.PI
fun calcularAreaCircunf(raio: Double): Double {
    return PI * raio * raio
}
fun main(args: Array<String>){
    //função para calcular a área da circunferência
    val raioCircunf = 3.0
    val areaCircunf = calcularAreaCircunf(raioCircunf)
    println("A área da circunferência é: $areaCircunf")
}