package areas

fun calcularAreaLosango(diagonalMaior: Double, diagonalMenor: Double): Double {
    return (diagonalMaior * diagonalMenor) / 2
}
fun main(args: Array<String>){
    //funcao para calcular a área do losango
    val diagMaiorLosango = 7.0
    val diagMenorLosango = 4.0
    val areaLosango = calcularAreaLosango(diagMaiorLosango, diagMenorLosango)
    println("A área do losango é: $areaLosango")
}